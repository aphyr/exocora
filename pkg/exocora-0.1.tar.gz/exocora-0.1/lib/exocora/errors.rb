module Exocora
  class ScriptError < RuntimeError
  end

  class TemplateError < RuntimeError
  end
end
