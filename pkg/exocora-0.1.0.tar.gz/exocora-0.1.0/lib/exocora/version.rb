module Exocora
  APP_NAME = 'exocora'
  APP_VERSION = '0.1.0'
  APP_AUTHOR = 'aphyr'
  APP_EMAIL = 'aphyr@aphyr.com'
  APP_URL = 'http://aphyr.com/'
  APP_COPYRIGHT = 'Copyright (c) 2008 aphyr <aphyr@aphyr.com>. All rights reserved.'
end
